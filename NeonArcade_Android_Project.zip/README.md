# Neon Arcade — Android APK project

This is an Android Studio project wrapping the Neon Arcade HTML game in a native Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select Build > Build APK(s).
4. Install the generated APK on your Samsung Galaxy S10e.

The app is offline and uses the game's local storage for coins/level progress.
